# TETRIS JS

A Pen created on CodePen.

Original URL: [https://codepen.io/Claudia-Moreno/pen/KKEgRQm](https://codepen.io/Claudia-Moreno/pen/KKEgRQm).

